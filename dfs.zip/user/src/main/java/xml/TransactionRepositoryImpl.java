package xml;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import snippet.Transaction;
import snippet.TransactionRepository;

//import ;
//import common.FlightRepository;

public class TransactionRepositoryImpl  implements TransactionRepository {

	//CarEngine
	public TransactionRepositoryImpl() {
		System.out.println("FlightRepositoryImpl() ctor..");
	}
	private DataSource dataSource; //driver/url/username/password
	
	public void setDataSource(DataSource d) {
		System.out.println("setDateSource(DataSource) setter method invoked...");
		this.dataSource = d;
	}

	public List<Transaction> getAvailableTransactions() {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			conn = dataSource.getConnection();
			String sql = "select * from Transaction";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			List<Transaction> rows = new ArrayList<Transaction>();
			
			while(rs.next()) { //each row
				
				Transaction f = new Transaction(); //blank object
				
				f.setAcc(rs.getString(1)); //fillup
				f.setPayeeAccountNo(rs.getString(2));//fillup
				f.setTransactionID(rs.getString(3));//fillup
				f.setDate1(rs.getString(4));//fillup
				f.setType1(rs.getString(5));
				f.setCredit(rs.getInt(6));
				f.setDebit(rs.getInt(7));
				//f.setType1(rs.getString(8));
				f.setRemarks(rs.getString(8));
				
				rows.add(f); //store it in list
			}
			return rows;
		}
		catch(SQLException e) {
			throw new RuntimeException(e);
		}
		finally {
			try { rs.close(); pst.close(); conn.close(); } catch(Exception e) { 
				
				System.out.println("error "+e);
			}
		}
	}
}
