package snippet;

public class Transaction {
	
	private String Acc;
	private String PayeeAccountNo;
	private String TransactionID;
	private String Date1;
	//private String Time1;
	private String Type1;
	private int Debit;
	private int Credit;
	private String Remarks;
	
	
	public String getAcc() {
		return Acc;
	}
	public void setAcc(String acc) {
		Acc = acc;
	}
	public String getPayeeAccountNo() {
		return PayeeAccountNo;
	}
	public void setPayeeAccountNo(String payeeAccountNo) {
		PayeeAccountNo = payeeAccountNo;
	}
	public String getTransactionID() {
		return TransactionID;
	}
	public void setTransactionID(String transactionID) {
		TransactionID = transactionID;
	}
	public String getDate1() {
		return Date1;
	}
	public void setDate1(String date1) {
		Date1 = date1;
	}
//	public String getTime1() {
//		return Time1;
//	}
//	public void setTime1(String time1) {
//		Time1 = time1;
//	}
	public String getType1() {
		return Type1;
	}
	@Override
	public String toString() {
		return "Transaction [Acc=" + Acc + ", PayeeAccountNo=" + PayeeAccountNo + ", TransactionID=" + TransactionID
				+ ", Date1=" + Date1 + ", Type1=" + Type1 + ", Debit=" + Debit + ", Credit=" + Credit + ", Remarks="
				+ Remarks + "]";
	}
	public void setType1(String type1) {
		Type1 = type1;
	}
	public int getDebit() {
		return Debit;
	}
	public void setDebit(int debit) {
		Debit = debit;
	}
	public int getCredit() {
		return Credit;
	}
	public void setCredit(int credit) {
		Credit = credit;
	}
	public String getRemarks() {
		return Remarks;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
}

	
	