package snippet;

import java.util.List;

//import common.Dept;
//import common.Flight;

//import common.Flight;

public interface TransactionRepository {

	public List<Transaction> getAvailableTransactions();

	//void addTransaction(String TransactionId); 
//	public Transaction getTransactionByTransactionId(String TransactionId);
	 //void updateDepartment(Dept ref); 
	// void deleteTransaction(String dno);

	//import java.util.List;
}
