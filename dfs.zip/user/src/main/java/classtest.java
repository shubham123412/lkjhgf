import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import snippet.Transaction;
import xml.TransactionRepositoryImpl;

public class classtest {

	
		public static void main(String[] args) {
					
			ApplicationContext container = new ClassPathXmlApplicationContext("myspring.xml");
					
			TransactionRepositoryImpl fr = (TransactionRepositoryImpl) container.getBean("DeptRepo");
					
			List<Transaction> flightList = fr.getAvailableTransactions();
			for (Transaction flight : flightList) {
				System.out.println("Flight : "+flight);
				}
}
}
